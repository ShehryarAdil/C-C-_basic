#include<stdio.h>
#include<conio.h>

int main ()
{
    int b,a,c,d,e,f,g,h;
    
    printf ("\n\t The last givin no are 16 & 26\n ") ;
    a=26;
    b=16;
    {
    c=a-b;
    printf ("\t%d",c);
    d=b-c;
    printf ("\n\t%d",d);
    e=c-d;
    printf ("\n\t%d",e);
    f=d-e;
    printf ("\n\t%d",f);
    g=e-f;
    printf ("\n\t%d",g);
    h=f-g;
    printf ("\n\t%d",h);
    }
    getch();
    return 0;
}