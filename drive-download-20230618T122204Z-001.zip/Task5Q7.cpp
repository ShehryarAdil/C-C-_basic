#include<stdio.h>
#include<conio.h>

int main () 
{
    int num,count=0,cnt,res=0,rem,mul=1;
    
    printf ("\n\t Enter a number: ") ;
    scanf (" %d",&num) ;
    
    int q = num;
    while (q != 0)
    {
        q = q/10;
        count++;
    }
    cnt = count;
    q = num;
    while (q != 0)
    {
        rem=q%10;
        while (cnt != 0)
        {
            mul=mul*rem;
            cnt--;
        }
        res=res+mul;
        cnt = count;
        q=q/10;
        mul=1;
    }
    if (res==num)
    {
        printf ("\n\t %d is an armstrong number ",num) ;
    }
    else
    {
        printf ("\n\t %d is not an armstrong number ",num) ;
    }
    getch ();
    return 0;
} 
