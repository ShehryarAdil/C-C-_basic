#include<stdio.h>
#include<conio.h>

int main ()
{
    int pow,i;
    float no,res;

    printf ("\n\t enter the value of base. ") ;
    scanf (" %f",&no) ;
    res=no;
    printf ("\n\t enter the value of power. ") ;
    scanf (" %d",&pow) ;
    
    if (pow>0)
    {
        for (i=2;i<=pow;i++)
        {
            res=res*no;
        }
    }
    if (pow<0)
    {
        pow=pow* -1;
        for (i=2;i<=pow;i++)
        {
            res=res*no;
        }
        res=1/res;
    }
    pow=pow* -1;
    printf ("\n\t %.2f rise to the power %d is %.2f",no,pow,res) ;
    return 0; 
}
