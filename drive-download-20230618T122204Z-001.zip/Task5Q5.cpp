#include<stdio.h>
#include<conio.h>

int main () 
{
    int no;
    
    printf ("\n\t Enter any no. ") ;
    scanf ("%d",&no) ;
    
    if (no%2==0)
    {
        printf ("\n\t Entered no was %d and largest fector is %d ",no,no/2) ;
    }
    else if (no%3==0)
    {
        printf ("\n\t Entered no was %d and largest fector is %d ",no,no/3) ;
    }
    else
    {
        printf ("\n\t Entered no was %d and largest fector is %d ",no,no) ;
    }
    
    getch ();
    return 0;
} 