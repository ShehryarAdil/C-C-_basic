#include<iostream>
#include<conio.h>
using namespace std;
class student{
	public:
		student(){
			void Sam();
			void John();
		}
		void Sam(){
			cout<<"\nName: Sam\nPhone No.: 9345673829\nAddress:No 21, 15 Alpha St, Babol, Mazandaran, Iran";
		}
		void Jhon(){
				cout<<"\nName: Jhon\nPhone No.: 93456756829\nAddress:No 78, 15 Love St, Babol, Mazandaran, Iran";
		}
};
int main()
{
	student obj1;
	obj1.Sam();
	cout<<"\n\n\n";
	student obj2;
	obj2.Jhon();

	getch();
}
	

		
