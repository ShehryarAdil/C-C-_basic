#include<iostream>
#include<conio.h>
using namespace std;
class time{
	public:
		int hr,min;
		time(){
			hr = 0;
			min = 0;
		}
		int tm_convert(int s)
			{
				while(s >= 60){
					

						if(s >= 3600)
							{
								hr++;
								s= s-3600;
								//return s;
							}
						else if( s >= 60)
							{
								min++;
								s = s-60;
								//return s;
							}
						else
							return s;
				}
				
					return s;
			}
};
int main()
{
	time obj;
	int i,secc;
	cout<<"Enter the time in(sec) you want to  convert it in (HH:MM:SS) format:\n==";
	cin>>i;
	secc = obj.tm_convert(i);
	cout<<"\nHH:\t"<<obj.hr<<"\nMM:\t"<<obj.min<<"\nSS:\t"<<secc;
	getch();
}






