#include<iostream>
#include<conio.h>
using namespace std;
class Rectangle{
	public:
		Rectangle(){
			void area_rec(int,int);
				}	
		void area_rec(int l, int b)
				{
					int area =1;
						area = l*b;
							cout<<"\nArea of Reactangle is =="<<area<<"m2";
				}
};
int main()
{
	Rectangle obj;
	cout<<"\nArea of 1st Traingle is :";
	obj.area_rec(4,5);
	cout<<"\nArea of 2nd Traingle is :";
	obj.area_rec(5,8);
	getch();
}