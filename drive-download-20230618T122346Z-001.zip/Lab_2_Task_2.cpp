#include<iostream>
#include<conio.h>
//#include<string.h>
#include<string>
using namespace std;
class student{
	public:
		string name;
		int roll_no;
		student()
		{
			name = "JHON";
			roll_no = 2;
		}
};
int main()
{
	student obj;
	obj.name;
	cout<<"Roll No:  Name:\n";
	cout<<obj.roll_no<<"\t"<<obj.name;
	getch();
}
