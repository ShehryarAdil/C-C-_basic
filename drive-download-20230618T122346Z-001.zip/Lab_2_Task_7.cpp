#include<iostream>
#include<conio.h>
using namespace std;
class Area{
	public:
		int setDim()
			{
				int ans,b,l;
				cout<<"\nEnter THe Lenght of a Rectangle :|\t";
				cin>>b;
				cout<<"\nEnter THe Breadth of a Rectangle :|\t";
				cin>>l;
				ans = getArea(b,l);
				return ans;
			}
		int getArea(int x,int y)
			{
				int area;
				area = x*y;
				return area;
			}
};
int main()
{
	Area obj;
	cout<<"\nArea of a a Rectangle:|";
	int ans;
	ans = obj.setDim();
	cout<<"\nThe Area of an rectangle is==: "<<ans;
	getch();
}
