#include<iostream>
#include<conio.h>
using namespace std;
class Average{
	public:
		float average(int x, int y, int z)
			{
				float ans;
				ans = (x+y+z)/3;
				return ans;
			}

};
class Num:public Average{
	public:
		
};
int main()
{
	Num obj1;
	int a,b,c;
	float rslt;
	cout<<"\nTo Calculate the average of Three Numbers: ";
	cout<<"\nNum 1 : ";
	cin>>a;
	cout<<"\nNum 2 : ";
	cin>>b;
	cout<<"\nNum 3 : ";
	cin>>c;
	rslt = obj1.average(a,b,c);
	cout<<"\nTHe average of "<<a<<", "<<b<<"and "<<c<<" is : "<<rslt;
	getch();
}
