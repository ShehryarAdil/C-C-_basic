#include<iostream>
#include<conio.h>
using namespace std;
class AddDistance{
	public:
		void Sum(int x, int y)
			{
				int a =x+y;
				cout<<"\nYour Resultant Distance is:"<<a;
			}
};
int main()
{
	int a,b;
	AddDistance obj;
	cout<<"Input the two distance in (inch or feet)";
	cout<<"\nDistance 1:";
	cin>>a;
	cout<<"\nDistance 2:";
	cin>>b;
	obj.Sum(a,b);
	getch();
}
