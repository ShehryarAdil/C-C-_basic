#include<iostream>
#include<conio.h>
using namespace std;
class complex{
	public:
		void add_com(int r1,int r2,int i1,int i2)
			{
				int ans1,ans2;
				ans1 = r1+r2;
				ans2 = i1+i2;
				cout<<"\nThe Sum of two Complex num is : "<<ans1<<"+"<<ans2<<"i";
			}
		void diff_com(int r1,int r2,int i1,int i2)
			{
				int ans1,ans2;
				ans1 = r1-r2;
				ans2 = i1-i2;
				cout<<"\nThe Difference of two Complex num is : "<<ans1<<"+"<<ans2<<"i";
			}
		void pro_com(int r1, int r2,int i1,int i2)
			{
				int ans1,ans2,m;
				ans1 = r1*r2;
				ans2 = i1*i2*(-1);
				ans1 = ans1+ans2;
				m = r1*i2;
				ans2 = r2*i1;
				ans2 = m+ans2;
				cout<<"\nThe Productg  of two Complex num is : "<<ans1<<"+"<<ans2<<"i";
			}
};
int main()
{
	complex obj;
	int i1,i2,r1,r2,s;
	cout<<"\nCOMPLEX NUMBER 1 :";
	cout<<"\nEnter Real part : ";
	cin>>r1;
	cout<<"\nEnter Imaginary part : ";
	cin>>i1;
	cout<<"\n"<<r1<<"+"<<i1<<"i";
	cout<<"\nCOMPLEX NUMBER 2 :";
	cout<<"\nEnter Real part : ";
	cin>>r2;
	cout<<"\nEnter Imaginary part : ";
	cin>>i2;
	cout<<"\n"<<r2<<"+"<<i2<<"i";
	do{
		cout<<"\n\nWhat do you find for that num:";
		cout<<"\n1 : Sum\n2 : Difference\n3 : Product\n4 : Exit";
		switch(s)
			{
				case 1:
					{
						obj.add_com(r1,r2,i1,i2);
					}
				case 2:
					{
						obj.diff_com(r1,r2,i1,i2);
					}
				case 3:
					{
						obj.pro_com(r1,r2,i1,i2);
					}
				case 4:
					return s;
			}
		}while(s != 4);						
	
getch();
}


