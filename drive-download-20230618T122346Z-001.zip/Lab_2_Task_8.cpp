#include<iostream>
#include<conio.h>
using namespace std;
class Area{
	public:
		int b;
		int l;
		Area(){
			b = 24;
			l = 33;
		}
		int getArea(int x,int y)
			{
				int area;
				area = x*y;
				return area;
			}
};
int main()
{
	Area obj;
	int ans;
	cout<<"\nArea of a a Rectangle:|";
	cout<<"\nTHe Initialized Lenght of a Rectangle :|\t"<<obj.b;;
	cout<<"\nTHe Initialized Breadth of a Rectangle :|\t"<<obj.l;
	ans = obj.getArea(obj.b,obj.l);
	cout<<"\nThe Area of an rectangle is==: "<<ans;
	getch();
}