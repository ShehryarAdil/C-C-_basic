#include<iostream>
#include<conio.h>
using namespace std;
class Employee{
	public:
		void emp(){
			cout<<"Name\t\tYear of joining\t\tAddress";
			cout<<"\nRobert\t\t1994\t\t\t64C-WallsStreet\nSam\t\t2000\t\t\t68D-WallsStreet\nJhon\t\t1999\t\t\t26B-WallsStreet";
		}
};
int main()
{
	Employee obj;
	obj.emp();
	getch();
}
