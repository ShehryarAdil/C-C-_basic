#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int x,n,ans;
	cout<<"\nEnter the Number X :";
	cin>>x;
	cout<<"\nEnter the power N :";
	cin>>n;
	ans =x;
	for(int i=1; i<n; i++)
		{
			ans = ans*x;
		}
	cout<<"\nYou`re Given Value is : "<<ans;
	getch();
}