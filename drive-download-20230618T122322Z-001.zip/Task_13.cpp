#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int a,b,ans;
	cout<<"\nNumbers to be Multiply: ";
	cout<<"\nEnter Num.1 : ";
	cin>>a;
	cout<<"\nEnter Num.2 : ";
	cin>>b;
	ans = a*b;
	cout<<"\nMultiplied Number is : "<<ans;
	getch();
}

