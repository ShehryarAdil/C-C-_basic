#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int a,b;
	int q,r=0;
	cout<<"\nEnter The Num.(Divided) :";
	cin>>a;
	cout<<"\nEnter The Num.(Divisor) :";
	cin>>b;
	q = a/b;
	r = a%b;
	cout<<"\nEnter The Num.(Divided) :\t"<<a;
	cout<<"\nEnter The Num.(Divisor) :\t"<<b;
	cout<<"\nEnter The Num.(Quotient) :\t"<<q;
	cout<<"\nEnter The Num.(Remainder) :\t"<<r;
	getch();
}
