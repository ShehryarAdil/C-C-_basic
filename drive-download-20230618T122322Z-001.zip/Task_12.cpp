#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1, num2;
	cout<<"\nNum 1: ";
	cin>>num1;
	cout<<"\nNum 2: ";
	cin>>num2;
	cout<<"\nBy swapping: \nNow";
	num1 = num1 + num2;
	num2 = num1 - num2;
	num1 = num1 - num2;
	cout<<"\nNum 1: "<<num1;
	cout<<"\nNum 2: "<<num2;
	getch();
}

