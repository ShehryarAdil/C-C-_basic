#include<iostream>
#include<conio.h>
using namespace std;
int main ()
{
	int num;
	int i;

	cout<<"Enter Any Number that For Drawing Table for that==";
	cin>>num;

	for(i=1; i<=12 ; i++)
		cout<<"\t\t"<<num<<" * "<<i<<" = "<<i*num<<"\n";


	getch();
}