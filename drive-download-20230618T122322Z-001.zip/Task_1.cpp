



#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1 = 10;
	int num2 = 15;
	float num3 = 12.6;


cout<<"Print num_1 is =="<<num1;
cout<<"\nPrint num_2 is =="<<num2;
cout<<"\nPrint num_3 is =="<<num3;

getch();
return 0;
}