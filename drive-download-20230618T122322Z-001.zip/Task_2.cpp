


#include<iostream>
#include<conio.h>
#include<string>
using namespace std;

int main()
{
	string Name;

cin>> Name;
cout<< Name;
getch();
return 0;
}