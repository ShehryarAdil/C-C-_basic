

#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num,rem;	

	cout<<"\nEnter any number you want to check==";
	cin>>num;
	
	rem = num;
	rem = rem%2;

	if(rem == 0)
		{
		cout<<"\nYour`e Entered Number is EVEN";
		}
	else if(rem == 1)
		{
		cout<<"\nYour`e Entered Number is Odd";
		}
	else
		{
		cout<<"\nYou entered zero";
		}
	//return 0;
	getch();

}



	