



#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1, num2,ans;
	cout<<"Enter 1st Number=";
	cin>>num1;
	cout<<"\nEnter 2nd Number=";
	cin>>num2;

	ans = num1 + num2;

	cout<<"\n"<<num1<<" + "<<num2<<" = "<<ans;

getch();
}