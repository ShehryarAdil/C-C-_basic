#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;
int main()
{
	double num;
	float ans;
	cout<<"Enter the Number You want to find its Square root :";
	cin>>num;
	ans = pow(num,1.0/2.0);
	cout<<"\nThe square root of given num is :"<<ans;
	getch();
}
