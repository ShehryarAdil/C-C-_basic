#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int d,y,w;
	y =0;
	w = 0;
	cout<<"\nEnter Days you want to convert :";
	cin>>d;
	while(d > 7)
		{
		if(d >= 365)
			{
				y++;
				d = d-365;
			}
		else if(d >= 7)
			{
				w++;
				d = d-7;
			}
		else 
			return d;
		}
	cout<<"\n Years :"<<y;
	cout<<"\n Weeks :"<<w;
	cout<<"\n Days :"<<d;
	getch();
}