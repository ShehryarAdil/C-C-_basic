#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1,num2;
	int max = 0;
	cout<<"\nEnter num you want to find its L.C.M : ";
	cout<<"\n Num 1: ";
	cin>>num1;
	cout<<"\n Num 2: ";
	cin>>num2;
	max = num1*num2;
	for(int i=1; i<=max; i++)
		{
			if(max%i==0  && i%num1==0 && i%num2==0)
				{
					cout<<"\nThe L.C.M of "<<num1<<" and "<<num2<<" is : "<<i;

				break;
				}
		}
	getch();

}
