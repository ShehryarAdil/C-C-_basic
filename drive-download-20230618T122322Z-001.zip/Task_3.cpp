



#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int arr[3];
	int count =0;
	int i;

while( count < 3 )
{
	cout<<"\nEnter Value ==";
	cin>> arr[count];
	count++;
}
for (i=0; i <3 ; i++)
	cout<<"\n"<<arr[i];

for (i = 2; i>=0; i--)
	cout<<"\n"<<arr[i];


getch();
return 0;
}

