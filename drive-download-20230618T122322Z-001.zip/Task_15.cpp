#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int c,a,b;
	cout<<"\nEnter the 1st Num :";
	cin>>a;
	cout<<"\nEnter the 2nd Num :";
	cin>>b;
	c = a+b;
	cout<<"\nThe sum is :"<<c;
	getch();
}
