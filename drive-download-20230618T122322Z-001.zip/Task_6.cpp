


#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num,i;
	int arr[3] = {2,3,5};


	cout<<"\nEnter Any Number To check where it is Prime Number or not";
	cin>> num;
	
	i = 0;

	while(i <3)
	{
		num = num%arr[i];

			if(num == 1 || num == 2)
				{
					cout<<"\nThis is an prime number";
				}
			else
			{
				cout<<"\nThis is not an prime number";
			}
		i++;
	}
	getch();

}


