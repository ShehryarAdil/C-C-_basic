


#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int num,i=0;
	int a,ans = 1;
	cout<<"\nEnter Any Number";
	cin>>num;
	
	a= num;

	while( i < a)
	{
			
		ans = ans*num;
		
		i++;
		num--;
	}
	cout<<"\nThe Factorial of:"<<a<<" is =="<<ans;

getch();
}