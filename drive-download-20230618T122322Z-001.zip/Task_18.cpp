#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"\nTo find Largest Num. Among three";
	cout<<"\nEnter Num 1 :";
	cin>>a;
	cout<<"\nEnter Num 2 :";
	cin>>b;
	cout<<"\nEnter Num 3 :";
	cin>>c;
	if(a > b && a > c)
		cout<<"\nThis num : "<<a<<" Largest among them i.e "<<b<<" and "<<c;
	else if(b > a && b > c)
		cout<<"\nThis num : "<<b<<" Largest among them i.e "<<a<<" and "<<c;
	else if(c > a && c > b)
		cout<<"\nThis num : "<<c<<" Largest among them i.e "<<a<<" and "<<b;
	getch();
}